# Diya

A Pen created on CodePen.

Original URL: [https://codepen.io/Shini-Suga/pen/VYjBBZm](https://codepen.io/Shini-Suga/pen/VYjBBZm).

